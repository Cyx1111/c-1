﻿Partial Public Class MainPage
    Inherits UserControl

	Public Sub New()
		' Required to initialize variables
		InitializeComponent()
	End Sub

End Class