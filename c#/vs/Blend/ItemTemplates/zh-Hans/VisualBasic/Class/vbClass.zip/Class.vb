﻿Imports System
Imports System.IO
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Media
Imports System.Windows.Media.Animation

Public Class $safeitemname$
	Public Sub New()
		' Insert code required on object creation below this point.
	End Sub
End Class
