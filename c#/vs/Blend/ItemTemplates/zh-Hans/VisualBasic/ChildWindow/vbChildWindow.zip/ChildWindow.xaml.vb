﻿imports System
imports System.Collections.Generic
imports System.Linq
imports System.Windows
imports System.Windows.Controls
imports System.Windows.Documents
imports System.Windows.Input
imports System.Windows.Media
imports System.Windows.Media.Animation
imports System.Windows.Shapes


Partial Public Class $safeitemname$
    Inherits ChildWindow

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub OKButton_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles OKButton.Click
        Me.DialogResult = True
    End Sub

    Private Sub CancelButton_Click(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles CancelButton.Click
        Me.DialogResult = False
    End Sub

End Class
